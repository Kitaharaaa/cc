"""
Crypto Screener Web App
- Dashboard web live (buka dari HP/laptop), scan otomatis berkala.
- Hanya screener/alert: TIDAK ada eksekusi trading, tidak butuh API bursa.
Bukan saran keuangan.
"""

import json
import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from flask import Flask, Response, jsonify

import screener as sc

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("app")

SCAN_INTERVAL_MIN = int(os.getenv("SCAN_INTERVAL_MIN", "15"))
MIN_SCORE = int(os.getenv("MIN_SCORE", "60"))             # skor minimal untuk masuk riwayat sinyal
COOLDOWN_HOURS = float(os.getenv("COOLDOWN_HOURS", "6"))  # anti-duplikat per koin & sinyal
DATA_DIR = os.getenv("DATA_DIR", "data")
HISTORY_FILE = os.path.join(DATA_DIR, "history.json")
MAX_HISTORY = 100

INDEX_HTML = r"""<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0b0f17">
<title>Crypto Screener</title>
<style>
:root{
  --bg:#0b0f17; --panel:#121826; --panel2:#18202f; --line:#243049;
  --text:#e8edf6; --muted:#8a96ad; --green:#22c55e; --red:#ef4444;
  --amber:#f59e0b; --blue:#4f8cff;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font:15px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:0 16px 48px}
header{position:sticky;top:0;z-index:5;background:rgba(11,15,23,.92);backdrop-filter:blur(8px);border-bottom:1px solid var(--line)}
.bar{max-width:1180px;margin:0 auto;padding:12px 16px;display:flex;gap:12px;align-items:center;flex-wrap:wrap}
h1{font-size:18px;margin:0;flex:1 1 auto;display:flex;align-items:center;gap:8px}
.dot{width:9px;height:9px;border-radius:50%;background:var(--green);box-shadow:0 0 8px var(--green)}
.dot.busy{background:var(--amber);box-shadow:0 0 8px var(--amber);animation:pulse 1s infinite}
@keyframes pulse{50%{opacity:.35}}
.sub{color:var(--muted);font-size:12.5px}
button{background:var(--panel2);color:var(--text);border:1px solid var(--line);border-radius:10px;padding:8px 12px;font:inherit;font-size:13px;cursor:pointer}
button:hover{border-color:var(--blue)}
button:disabled{opacity:.5;cursor:default}
.chips{display:flex;gap:8px;margin:16px 0 8px;flex-wrap:wrap}
.chip{padding:6px 12px;border-radius:999px;background:var(--panel);border:1px solid var(--line);font-size:13px;color:var(--muted);cursor:pointer}
.chip.on{color:var(--text);border-color:var(--blue);background:#16233d}
.chip b{color:var(--text)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(310px,1fr));gap:14px;margin-top:10px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:16px;display:flex;flex-direction:column;gap:12px}
.card.buy{border-color:#1f6b3d;box-shadow:0 0 0 1px #1f6b3d33 inset}
.card.sell{border-color:#7a2a2a;box-shadow:0 0 0 1px #7a2a2a33 inset}
.row{display:flex;justify-content:space-between;align-items:center;gap:10px}
.sym{font-weight:700;font-size:17px}
.sym small{color:var(--muted);font-weight:500}
.badge{font-size:11.5px;font-weight:700;padding:4px 9px;border-radius:999px;letter-spacing:.3px}
.badge.BUY{background:#0f3a22;color:#4ade80}
.badge.SELL{background:#3d1717;color:#f87171}
.badge.NONE{background:#1b2436;color:var(--muted)}
.price{font-size:22px;font-weight:700;font-variant-numeric:tabular-nums}
.chg{font-size:13px;font-weight:600}
.up{color:var(--green)} .down{color:var(--red)}
.metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.m{background:var(--panel2);border-radius:10px;padding:8px 10px}
.m span{display:block;font-size:11px;color:var(--muted)}
.m b{font-size:14px;font-variant-numeric:tabular-nums}
.rsibar{height:5px;border-radius:3px;background:linear-gradient(90deg,var(--green) 0 40%,#334155 40% 70%,var(--red) 70% 100%);position:relative;margin-top:6px}
.rsibar i{position:absolute;top:-3px;width:3px;height:11px;background:#fff;border-radius:2px}
.targets{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.t{border-radius:10px;padding:8px 10px;background:var(--panel2)}
.t span{display:block;font-size:11px;color:var(--muted)}
.t b{font-size:14px;font-variant-numeric:tabular-nums}
.t.g b{color:var(--green)} .t.r b{color:var(--red)}
.full{grid-column:1/-1}
.reason{font-size:13px;color:#c3ccdd}
.score{display:flex;align-items:center;gap:10px}
.ring{--p:0;width:46px;height:46px;border-radius:50%;display:grid;place-items:center;
  background:conic-gradient(var(--c) calc(var(--p)*1%),#243049 0);position:relative;font-weight:700;font-size:13px}
.ring::before{content:"";position:absolute;inset:5px;background:var(--panel);border-radius:50%}
.ring span{position:relative}
svg.spark{width:100%;height:38px}
h2{font-size:16px;margin:30px 0 10px}
.hist{background:var(--panel);border:1px solid var(--line);border-radius:16px;overflow:hidden}
.h{display:grid;grid-template-columns:auto 1fr auto;gap:12px;padding:12px 16px;border-bottom:1px solid var(--line);align-items:center}
.h:last-child{border:0}
.h small{color:var(--muted)}
.empty{padding:22px;text-align:center;color:var(--muted)}
.note{margin-top:30px;font-size:12px;color:var(--muted);text-align:center}
.warn{background:#2a1f0a;border:1px solid #5b4310;color:#f5c26b;padding:10px 14px;border-radius:12px;font-size:13px;margin-top:12px;display:none}
@media(max-width:520px){.bar button{flex:1}}
</style>
</head>
<body>
<header>
  <div class="bar">
    <h1><span class="dot" id="dot"></span> Crypto Screener</h1>
    <div class="sub" id="status">Memuat…</div>
    <button id="btnNotif">🔔 Notifikasi</button>
    <button id="btnScan">⟳ Scan sekarang</button>
  </div>
</header>

<div class="wrap">
  <div class="warn" id="warn"></div>
  <div class="chips" id="chips"></div>
  <div class="grid" id="grid"></div>

  <h2>Riwayat Sinyal</h2>
  <div class="hist" id="hist"></div>

  <div class="note">
    Alat bantu analisis, bukan saran keuangan. Target &amp; estimasi waktu dihitung dari indikator dan volatilitas,
    bukan jaminan. Selalu gunakan Stop Loss dan lakukan riset sendiri.
  </div>
</div>

<script>
const $ = s => document.querySelector(s);
let state = null, filter = "ALL", seenIds = null;

const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function fp(p){
  if (p == null) return "-";
  if (p >= 100) return p.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
  if (p >= 1) return p.toFixed(4);
  return p.toFixed(6);
}
const fmtTime = t => t ? new Date(t*1000).toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"}) : "-";
const fmtDT = t => new Date(t*1000).toLocaleString("id-ID",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"});

function spark(values, up){
  if (!values || values.length < 2) return "";
  const w=300,h=38, min=Math.min(...values), max=Math.max(...values), rng=(max-min)||1;
  const pts = values.map((v,i)=>`${(i/(values.length-1)*w).toFixed(1)},${(h-2-((v-min)/rng)*(h-4)).toFixed(1)}`).join(" ");
  const c = up ? "#22c55e" : "#ef4444";
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><polyline fill="none" stroke="${c}" stroke-width="1.8" points="${pts}"/></svg>`;
}

function card(c){
  const cls = c.signal === "BUY" ? "buy" : c.signal === "SELL" ? "sell" : "";
  const label = c.signal === "BUY" ? "POTENSI NAIK (BUY)" : c.signal === "SELL" ? "SELL / TAKE PROFIT" : "NETRAL";
  const chg = c.change24h;
  const ringColor = c.signal === "SELL" ? "var(--red)" : "var(--green)";
  let body = "";
  if (c.signal !== "NONE") {
    body += `<div class="score"><div class="ring" style="--p:${c.score};--c:${ringColor}"><span>${c.score}</span></div>
             <div><div style="font-weight:600">Skor ${c.signal === "SELL" ? "Risiko Koreksi" : "Potensi"}</div>
             <div class="sub">dari 100</div></div></div>`;
  }
  if (c.signal === "BUY" && c.targets) {
    const t = c.targets;
    body += `<div class="targets">
      <div class="t full"><span>🛒 Area Beli Ideal</span><b>$${fp(t.zone_min)} – $${fp(t.zone_max)}</b></div>
      <div class="t g"><span>🎯 TP 1 (+${t.tp1_pct}%)</span><b>$${fp(t.tp1)}</b></div>
      <div class="t g"><span>🎯 TP 2 (+${t.tp2_pct}%)</span><b>$${fp(t.tp2)}</b></div>
      <div class="t r"><span>🛑 Stop Loss (−${t.sl_pct}%)</span><b>$${fp(t.sl)}</b></div>
      <div class="t"><span>⏱️ Estimasi Waktu</span><b>${esc(t.eta)}</b></div>
    </div>`;
  }
  return `<div class="card ${cls}">
    <div class="row"><div class="sym">${esc(c.symbol)}<small>/USDT</small></div><span class="badge ${c.signal}">${label}</span></div>
    <div class="row"><div class="price">$${fp(c.price)}</div>
      <div class="chg ${chg>=0?'up':'down'}">${chg>=0?'▲':'▼'} ${Math.abs(chg).toFixed(2)}% <span class="sub">24j</span></div></div>
    ${spark(c.spark, chg>=0)}
    <div class="metrics">
      <div class="m"><span>RSI 14</span><b>${c.rsi}</b><div class="rsibar"><i style="left:calc(${c.rsi}% - 1px)"></i></div></div>
      <div class="m"><span>EMA 20/50</span><b class="${c.trend==='up'?'up':'down'}">${c.trend==='up'?'Bullish':'Bearish'}</b></div>
      <div class="m"><span>Volume</span><b class="${c.vol_ratio>=1.3?'up':''}">${c.vol_ratio}×</b></div>
    </div>
    ${body}
    <div class="reason">💡 ${esc(c.reason)}</div>
  </div>`;
}

function render(){
  if (!state) return;
  const coins = state.coins;
  const nb = coins.filter(c=>c.signal==="BUY").length, ns = coins.filter(c=>c.signal==="SELL").length;
  const nn = coins.length - nb - ns;
  const chips = [["ALL",`Semua <b>${coins.length}</b>`],["BUY",`🟢 Buy <b>${nb}</b>`],["SELL",`🔴 Sell <b>${ns}</b>`],["NONE",`Netral <b>${nn}</b>`]];
  $("#chips").innerHTML = chips.map(([k,l])=>`<div class="chip ${filter===k?'on':''}" data-f="${k}">${l}</div>`).join("");
  const list = filter==="ALL" ? coins : coins.filter(c=>c.signal===filter);
  $("#grid").innerHTML = list.length ? list.map(card).join("") :
    `<div class="empty" style="grid-column:1/-1">${coins.length ? "Tidak ada koin pada filter ini." : "Scan pertama sedang berjalan… tunggu beberapa detik."}</div>`;

  const h = state.history;
  $("#hist").innerHTML = h.length ? h.map(x=>`
    <div class="h">
      <span class="badge ${x.signal}">${x.signal}</span>
      <div><b>${esc(x.pair)}</b> · skor ${x.score}<br><small>${fmtDT(x.time)} · $${fp(x.price)}${x.tp1?` · TP1 $${fp(x.tp1)} · SL $${fp(x.sl)}`:""}</small></div>
      <small>${x.signal==="BUY"?"Naik":"Turun"}</small>
    </div>`).join("")
    : `<div class="empty">Belum ada sinyal dengan skor ≥ ${state.config.min_score}. Screener terus memantau…</div>`;

  const errs = Object.keys(state.errors || {});
  const w = $("#warn");
  if (errs.length && !coins.length) { w.style.display="block"; w.textContent = "Gagal mengambil data pasar: " + state.errors[errs[0]]; }
  else if (errs.length) { w.style.display="block"; w.textContent = "Beberapa koin gagal dimuat: " + errs.join(", "); }
  else w.style.display = "none";
}

function tick(){
  if (!state) return;
  const m = state.meta, cfg = state.config;
  $("#dot").className = "dot" + (m.scanning ? " busy" : "");
  let s = `${cfg.timeframe} · ${cfg.total_coins} koin`;
  if (m.scanning) s += " · scanning…";
  else if (m.last_scan) {
    const left = Math.max(0, m.next_scan - Math.floor(Date.now()/1000 + state._skew));
    s += ` · scan ${fmtTime(m.last_scan)} · berikutnya ${Math.floor(left/60)}:${String(left%60).padStart(2,"0")}`;
  }
  $("#status").textContent = s;
}

function notifyNew(){
  const ids = state.history.map(h=>h.id);
  if (seenIds === null) { seenIds = new Set(ids); return; }
  const fresh = state.history.filter(h=>!seenIds.has(h.id));
  fresh.forEach(h=>{
    seenIds.add(h.id);
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(`${h.signal === "BUY" ? "📈 BUY" : "📉 SELL"} ${h.pair} (skor ${h.score})`,
        {body: `Harga $${fp(h.price)}` + (h.tp1 ? ` · TP1 $${fp(h.tp1)} · SL $${fp(h.sl)}` : "")});
      try { const a = new (window.AudioContext||window.webkitAudioContext)(), o = a.createOscillator();
        o.connect(a.destination); o.frequency.value = 880; o.start(); o.stop(a.currentTime + .18); } catch(e){}
    }
  });
}

async function load(){
  try {
    const r = await fetch("/api/state", {cache:"no-store"});
    state = await r.json();
    state._skew = state.now - Math.floor(Date.now()/1000);
    notifyNew(); render(); tick();
  } catch(e) { $("#status").textContent = "Koneksi ke server terputus…"; }
}

$("#chips").addEventListener("click", e => {
  const f = e.target.closest(".chip"); if (!f) return;
  filter = f.dataset.f; render();
});
$("#btnScan").addEventListener("click", async () => {
  const b = $("#btnScan"); b.disabled = true;
  await fetch("/api/scan", {method:"POST"});
  setTimeout(()=>{ b.disabled = false; load(); }, 4000);
});
$("#btnNotif").addEventListener("click", async () => {
  if (!("Notification" in window)) return alert("Browser ini tidak mendukung notifikasi.");
  const p = await Notification.requestPermission();
  $("#btnNotif").textContent = p === "granted" ? "🔔 Notifikasi aktif" : "🔕 Notifikasi ditolak";
});
if ("Notification" in window && Notification.permission === "granted") $("#btnNotif").textContent = "🔔 Notifikasi aktif";

load(); setInterval(load, 20000); setInterval(tick, 1000);
</script>
</body>
</html>
"""

app = Flask(__name__)

lock = threading.Lock()
results = {}          # {symbol: hasil analisis terbaru}
errors = {}           # {symbol: pesan error}
history = []          # riwayat sinyal (terbaru di depan)
meta = {"last_scan": None, "next_scan": None, "scans": 0, "scanning": False}
_last_manual = 0.0


# ---------------------------------------------------------------- riwayat
def load_history():
    global history
    try:
        with open(HISTORY_FILE, encoding="utf-8") as f:
            history = json.load(f)[:MAX_HISTORY]
    except Exception:
        history = []


def save_history():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history, f)
    except Exception as e:
        log.warning("Gagal menyimpan riwayat: %s", e)


def record_signal(res):
    """Catat sinyal ke riwayat jika skor cukup & tidak duplikat (cooldown)."""
    if res["signal"] == "NONE" or res["score"] is None or res["score"] < MIN_SCORE:
        return
    now = int(time.time())
    for h in history:
        if (h["symbol"] == res["symbol"] and h["signal"] == res["signal"]
                and now - h["time"] < COOLDOWN_HOURS * 3600):
            return
    t = res["targets"] or {}
    history.insert(0, {
        "id": f"{res['symbol']}-{res['signal']}-{now}",
        "time": now, "symbol": res["symbol"], "pair": res["pair"],
        "signal": res["signal"], "score": res["score"], "price": res["price"],
        "tp1": t.get("tp1"), "tp2": t.get("tp2"), "sl": t.get("sl"),
        "reason": res["reason"],
    })
    del history[MAX_HISTORY:]


# ---------------------------------------------------------------- scanner
def scan_all():
    with lock:
        if meta["scanning"]:
            return
        meta["scanning"] = True
    log.info("Mulai scan %d koin (timeframe %s)...", len(sc.COINS), sc.TIMEFRAME)

    def work(coin):
        try:
            return coin, sc.analyze(coin), None
        except Exception as e:
            return coin, None, str(e)

    try:
        with ThreadPoolExecutor(max_workers=4) as ex:
            for coin, res, err in ex.map(work, sc.COINS):
                with lock:
                    if err:
                        errors[coin] = err
                        log.error("Error pada %s: %s", coin, err)
                    else:
                        errors.pop(coin, None)
                        results[coin] = res
                        record_signal(res)
        with lock:
            save_history()
    finally:
        with lock:
            meta["scanning"] = False
            meta["last_scan"] = int(time.time())
            meta["next_scan"] = int(time.time()) + SCAN_INTERVAL_MIN * 60
            meta["scans"] += 1
        log.info("Scan selesai.")


def scanner_loop():
    while True:
        try:
            scan_all()
        except Exception as e:
            log.error("Scanner error: %s", e)
        time.sleep(SCAN_INTERVAL_MIN * 60)


_started = False


def start_scanner():
    global _started
    if _started:
        return
    _started = True
    load_history()
    threading.Thread(target=scanner_loop, daemon=True).start()


# ---------------------------------------------------------------- routes
@app.route("/")
def index():
    return Response(INDEX_HTML, mimetype="text/html")


@app.route("/api/state")
def api_state():
    with lock:
        coins = sorted(results.values(), key=lambda r: (
            {"BUY": 0, "SELL": 1, "NONE": 2}[r["signal"]], -(r["score"] or 0), r["symbol"]))
        return jsonify({
            "coins": coins,
            "errors": errors,
            "history": history[:50],
            "meta": meta,
            "config": {
                "timeframe": sc.TIMEFRAME, "interval_min": SCAN_INTERVAL_MIN,
                "min_score": MIN_SCORE, "total_coins": len(sc.COINS),
            },
            "now": int(time.time()),
        })


@app.route("/api/scan", methods=["POST"])
def api_scan():
    """Scan manual (dibatasi 1x per 30 detik)."""
    global _last_manual
    if time.time() - _last_manual < 30 or meta["scanning"]:
        return jsonify({"ok": False, "message": "Scan sedang berjalan / terlalu cepat."}), 429
    _last_manual = time.time()
    threading.Thread(target=scan_all, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/health")
def health():
    return {"status": "ok", "scans": meta["scans"], "last_scan": meta["last_scan"]}


start_scanner()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8080")))
