# Crypto Screener (siap Render)

File: app.py, screener.py, requirements.txt, render.yaml (semua di level paling atas repo, tanpa folder).

Render: New -> Blueprint -> pilih repo ini -> Apply. Setelah status Live, buka alamat .onrender.com.
Agar tidak tidur: UptimeRobot -> monitor HTTP ke https://NAMAAPP.onrender.com/health tiap 5 menit.
Bukan saran keuangan.
