"""
Engine screener: ambil data OHLCV, hitung indikator, deteksi sinyal, skor, target.
Murni analisis - tidak ada eksekusi trading.
"""

import logging
import math
import os
import time

import pandas as pd
import requests

log = logging.getLogger("screener")

# ----------------------------------------------------------------------
# KONFIGURASI (override lewat Environment Variables)
# ----------------------------------------------------------------------
COINS = [c.strip().upper() for c in os.getenv(
    "COINS",
    "BTC,ETH,SOL,XRP,ADA,NEAR,DOGE,BNB,AVAX,LINK,DOT,LTC,TRX,ATOM,SUI,APT"
).split(",") if c.strip()]

TIMEFRAME = os.getenv("TIMEFRAME", "1h")                  # 15m, 1h, 4h
VOLUME_SPIKE = float(os.getenv("VOLUME_SPIKE", "1.30"))    # 1.30 = +30% vs rata-rata 20 periode
RSI_OVERSOLD = float(os.getenv("RSI_OVERSOLD", "40"))
RSI_OVERBOUGHT = float(os.getenv("RSI_OVERBOUGHT", "70"))
CROSS_LOOKBACK = int(os.getenv("CROSS_LOOKBACK", "3"))     # cross valid dalam N candle terakhir

TF_HOURS = {"15m": 0.25, "1h": 1.0, "4h": 4.0}
BYBIT_INTERVAL = {"15m": "15", "1h": "60", "4h": "240"}
BINANCE_HOSTS = [
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
]

# ----------------------------------------------------------------------
# DATA OHLCV
# ----------------------------------------------------------------------
def fetch_binance(pair, limit=200):
    last_err = None
    for host in BINANCE_HOSTS:
        try:
            r = requests.get(f"{host}/api/v3/klines",
                             params={"symbol": pair, "interval": TIMEFRAME, "limit": limit},
                             timeout=15)
            if r.status_code == 200:
                df = pd.DataFrame(r.json(), columns=[
                    "open_time", "open", "high", "low", "close", "volume",
                    "close_time", "quote_vol", "trades", "taker_buy", "taker_quote", "ignore"])
                for c in ["open", "high", "low", "close", "volume", "taker_buy"]:
                    df[c] = df[c].astype(float)
                return df[["open", "high", "low", "close", "volume", "taker_buy"]]
            last_err = f"{host} -> HTTP {r.status_code}"
        except requests.RequestException as e:
            last_err = f"{host} -> {e}"
    raise RuntimeError(last_err)


def fetch_bybit(pair, limit=200):
    r = requests.get("https://api.bybit.com/v5/market/kline",
                     params={"category": "spot", "symbol": pair,
                             "interval": BYBIT_INTERVAL[TIMEFRAME], "limit": limit},
                     timeout=15)
    r.raise_for_status()
    rows = r.json()["result"]["list"][::-1]          # Bybit: terbaru dulu -> balik
    df = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close", "volume", "turnover"])
    for c in ["open", "high", "low", "close", "volume"]:
        df[c] = df[c].astype(float)
    df["taker_buy"] = float("nan")
    return df[["open", "high", "low", "close", "volume", "taker_buy"]]


def get_ohlcv(symbol):
    pair = f"{symbol}USDT"
    try:
        return fetch_binance(pair)
    except Exception as e:
        log.warning("Binance gagal untuk %s (%s). Mencoba Bybit...", pair, e)
        return fetch_bybit(pair)

# ----------------------------------------------------------------------
# INDIKATOR
# ----------------------------------------------------------------------
def calc_rsi(close, period=14):
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False).mean()
    rs = gain / loss.replace(0, float("nan"))
    return 100 - (100 / (1 + rs))


def calc_atr(df, period=14):
    prev_close = df["close"].shift(1)
    tr = pd.concat([df["high"] - df["low"],
                    (df["high"] - prev_close).abs(),
                    (df["low"] - prev_close).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / period, adjust=False).mean()
    return atr, (atr / df["close"]) * 100


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def fmt_duration(hours):
    lo, hi = hours * 0.6, hours * 1.6
    if hi <= 36:
        lo_r, hi_r = max(1, round(lo)), max(2, round(hi))
        if hi_r <= lo_r:
            hi_r = lo_r + 1
        return f"{lo_r} - {hi_r} Jam"
    lo_d, hi_d = max(1, round(lo / 24)), max(2, round(hi / 24))
    if hi_d <= lo_d:
        hi_d = lo_d + 1
    return f"{lo_d} - {hi_d} Hari"

# ----------------------------------------------------------------------
# TARGET, STOP LOSS, ESTIMASI WAKTU (berbasis volatilitas ATR)
# ----------------------------------------------------------------------
def calc_targets(price, atr, atr_pct):
    atr_pct = max(atr_pct, 0.1)
    tp1_pct = clamp(atr_pct * 2.0, 3.0, 5.0)
    tp2_pct = clamp(atr_pct * 4.0, 7.0, 12.0)
    sl_pct = clamp(atr_pct * 1.5, 3.0, 5.0)
    bars = (tp1_pct / atr_pct) ** 2                   # random-walk: jarak^2 / volatilitas^2
    hours = clamp(bars * TF_HOURS[TIMEFRAME], 3, 24 * 7)
    return {
        "tp1": price * (1 + tp1_pct / 100), "tp1_pct": round(tp1_pct, 1),
        "tp2": price * (1 + tp2_pct / 100), "tp2_pct": round(tp2_pct, 1),
        "sl": price * (1 - sl_pct / 100), "sl_pct": round(sl_pct, 1),
        "zone_min": max(price - 0.5 * atr, price * 0.985), "zone_max": price,
        "eta": fmt_duration(hours),
    }


def reason_text(signal, rsi, golden, death, vol_ratio):
    parts = []
    if signal == "BUY":
        if rsi < RSI_OVERSOLD:
            parts.append(f"RSI {rsi:.1f} masuk area oversold")
        if golden:
            parts.append("EMA 20 baru memotong EMA 50 ke atas (Golden Cross)")
        parts.append(f"volume naik {int((vol_ratio - 1) * 100)}% di atas rata-rata dengan tekanan beli dominan")
    elif signal == "SELL":
        if rsi > RSI_OVERBOUGHT:
            parts.append(f"RSI {rsi:.1f} masuk area overbought")
        if death:
            parts.append("EMA 20 memotong EMA 50 ke bawah (Death Cross)")
        parts.append("rawan koreksi, pertimbangkan ambil profit")
    else:
        return "Belum ada sinyal. Indikator masih dalam kondisi netral."
    text = ", ".join(parts)
    return text[0].upper() + text[1:] + "."

# ----------------------------------------------------------------------
# ANALISIS SATU KOIN
# ----------------------------------------------------------------------
def analyze(symbol):
    df_all = get_ohlcv(symbol)
    if len(df_all) < 60:
        raise RuntimeError("data historis kurang")

    price = float(df_all["close"].iloc[-1])
    bars24 = max(1, int(24 / TF_HOURS[TIMEFRAME]))
    change24h = (price / float(df_all["close"].iloc[-1 - bars24]) - 1) * 100
    spark = [float(x) for x in df_all["close"].iloc[-48:]]

    df = df_all.iloc[:-1].copy()                      # hanya candle yang sudah close
    df["rsi"] = calc_rsi(df["close"], 14)
    df["ema20"] = df["close"].ewm(span=20, adjust=False).mean()
    df["ema50"] = df["close"].ewm(span=50, adjust=False).mean()
    df["atr"], df["atr_pct"] = calc_atr(df, 14)

    last = df.iloc[-1]
    rsi = float(last["rsi"])
    if math.isnan(rsi):
        raise RuntimeError("RSI tidak valid")
    ema20, ema50 = float(last["ema20"]), float(last["ema50"])
    atr, atr_pct = float(last["atr"]), float(last["atr_pct"])

    avg_vol = df["volume"].iloc[-21:-1].mean()
    vol_ratio = float(last["volume"] / avg_vol) if avg_vol > 0 else 0.0

    if not math.isnan(last["taker_buy"]) and last["volume"] > 0:
        taker_ratio = float(last["taker_buy"] / last["volume"])
        buy_pressure = taker_ratio > 0.52 and last["close"] >= last["open"]
    else:
        taker_ratio = None
        buy_pressure = bool(last["close"] > last["open"])

    diff = (df["ema20"] - df["ema50"]).iloc[-(CROSS_LOOKBACK + 1):]
    golden = bool(((diff.shift(1) <= 0) & (diff > 0)).any())
    death = bool(((diff.shift(1) >= 0) & (diff < 0)).any())

    signal, score, targets = "NONE", None, None

    if ((rsi < RSI_OVERSOLD) or golden) and vol_ratio >= VOLUME_SPIKE and buy_pressure:
        signal = "BUY"
        s = 30.0
        if rsi < RSI_OVERSOLD:
            s += min(25, (RSI_OVERSOLD - rsi) * 1.25 + 8)
        if golden:
            s += 20
        s += 8 + min(7, (vol_ratio - VOLUME_SPIKE) * 7)
        if taker_ratio is not None and taker_ratio > 0.6:
            s += 5
        if price > ema50:
            s += 5
        score = int(clamp(round(s), 0, 100))
        targets = calc_targets(price, atr, atr_pct)
    elif rsi > RSI_OVERBOUGHT or death:
        signal = "SELL"
        s = 40.0
        if rsi > RSI_OVERBOUGHT:
            s += min(30, (rsi - RSI_OVERBOUGHT) * 1.5 + 10)
        if death:
            s += 20
        if vol_ratio >= VOLUME_SPIKE:
            s += 8
        if price < ema20:
            s += 5
        score = int(clamp(round(s), 0, 100))

    return {
        "symbol": symbol,
        "pair": f"{symbol}/USDT",
        "price": price,
        "change24h": round(change24h, 2),
        "rsi": round(rsi, 1),
        "ema20": ema20,
        "ema50": ema50,
        "trend": "up" if ema20 > ema50 else "down",
        "vol_ratio": round(vol_ratio, 2),
        "atr_pct": round(atr_pct, 2),
        "golden": golden,
        "death": death,
        "signal": signal,
        "score": score,
        "targets": targets,
        "reason": reason_text(signal, rsi, golden, death, vol_ratio),
        "spark": spark,
        "updated": int(time.time()),
    }
